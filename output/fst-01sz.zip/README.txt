README.txt: This file

BOM: BOM-fst-01sz.csv

For PCB:
	Top copper: FST-01SZ.GTL
	Top soldermask: FST-01SZ.GTS
	Top silkscreen: FST-01SZ.GTO
	Bottom copper: FST-01SZ.GBL
	Bottom soldermask: FST-01SZ.GBS
	Botom silkscreen: FST-01SZ.GBO
	Board Outline: FST-01SZ.GML
	Drills: FST-01SZ.TXT

For PCBA:

	Component Placement File: FST-01SZ-placement.CSV
	Top solderpaste: FST-01SZ.GTP
	How parts are placed: FST-01SZ-Dwgs.pdf


For parts which is not OPL, here are more information.

(1) GD32F103TBU6

    Giga Device 
    http://www.gigadevice.com/products/microcontrollers/gd32/arm-cortex-m3/mainstream-line/gd32f103-series/gd32f103tbu6/

    Possible suppliers:
    深圳市瑞江无限科技有限公司
    https://detail.1688.com/offer/573169039590.html

    深圳市铭顺信电子有限公司
    https://detail.1688.com/offer/568527808820.html


(2) ZL-272

    USB_A 手腕主体2.0
    广东中连精密工业有限公司, ShenZhen, China
    http://www.usbljq.com/m/?/goods/id-403/index.html

    Possible suppliers:
    广东中连精密工业有限公司
    https://detail.1688.com/offer/566273410945.html

    深圳市光明新区公明三杰盛电子经营部 
    https://detail.1688.com/offer/568913556657.html
-- 
